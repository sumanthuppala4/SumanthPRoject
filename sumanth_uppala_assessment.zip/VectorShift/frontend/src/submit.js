// submit.js
import { useStore } from "./store";
import { shallow } from "zustand/shallow";

export const SubmitButton = () => {
  const selector = (state) => ({
    nodes: state.nodes,
    edges: state.edges,
  });

  const { nodes, edges } = useStore(selector, shallow);

  const handleSubmit = async () => {
    try {
      const testData = { nodes, edges };
      console.log("Sending test data:", testData);

      const response = await fetch("http://localhost:8000/pipelines/parse", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(testData),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      alert(
        `No Of Nodes: ${data.num_nodes} No Of Edges: ${data.num_edges} Is DAG: ${data.is_dag}`
      );
      console.log("API response:", data);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  console.log("Nodes:", nodes);
  console.log("Edges:", edges);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <button type="submit" onClick={handleSubmit}>
        Submit
      </button>
    </div>
  );
};
