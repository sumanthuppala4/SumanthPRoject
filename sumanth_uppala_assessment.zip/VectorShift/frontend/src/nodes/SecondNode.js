// SecondNode.jsx
import { useState } from "react";
import { Position } from "reactflow";
import "./nodesStyles.css";
import { BaseNode } from "./baseNode";

export const SecondNode = ({ id }) => {
  const [count, setCount] = useState(1);
  const [mode, setMode] = useState("Auto");

  return (
    <BaseNode
      id={id}
      label="Second Node"
      description="Enter count and mode"
      handles={[
        { key: "in", type: "target", position: Position.Left },
        { key: "out", type: "source", position: Position.Right },
      ]}
    >
      <label className="label">
        Count:
        <input
          type="number"
          value={count}
          onChange={(e) => setCount(e.target.value)}
          className="input"
        />
      </label>

      <label className="label">
        Mode:
        <select
          value={mode}
          onChange={(e) => setMode(e.target.value)}
          className="select"
        >
          <option>Auto</option>
          <option>Manual</option>
        </select>
      </label>
    </BaseNode>
  );
};
