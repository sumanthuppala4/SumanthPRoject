// BaseNode.jsx
import { Handle } from "reactflow";
import "./nodesStyles.css";

export const BaseNode = ({
  id,
  label,
  description,
  handles = [],
  children,
}) => {
  return (
    <div className="container">
      {handles.map((h, i) => (
        <Handle
          key={i}
          type={h.type}
          position={h.position}
          id={`${id}-${h.key}`}
          style={h.style}
        />
      ))}

      <div>
        <span className="header">{label}</span>
      </div>

      {description && (
        <div>
          <span className="description">{description}</span>
        </div>
      )}

      {children}
    </div>
  );
};
