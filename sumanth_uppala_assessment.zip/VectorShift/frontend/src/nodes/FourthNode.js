// FourthNode.jsx
import { Position } from "reactflow";
import { BaseNode } from "./baseNode";

export const FourthNode = ({ id }) => (
  <BaseNode
    id={id}
    label="Fourth"
    description="This is the Fourth Node."
    handles={[
      { key: "input", type: "target", position: Position.Bottom },
      { key: "output", type: "source", position: Position.Top },
    ]}
  />
);
