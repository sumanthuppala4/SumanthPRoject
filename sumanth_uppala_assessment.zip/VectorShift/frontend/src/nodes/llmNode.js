// LLMNode.jsx
import { Position } from "reactflow";
import { BaseNode } from "./baseNode";

export const LLMNode = ({ id }) => {
  return (
    <BaseNode
      id={id}
      label="LLM"
      description="This is a LLM."
      handles={[
        {
          key: "system",
          type: "target",
          position: Position.Left,
          style: { top: `${100 / 3}%` },
        },
        {
          key: "prompt",
          type: "target",
          position: Position.Left,
          style: { top: `${200 / 3}%` },
        },
        {
          key: "response",
          type: "source",
          position: Position.Right,
        },
      ]}
    />
  );
};
