// TextNode.jsx
import { useState, useRef, useEffect } from "react";
import { Position } from "reactflow";
import "./nodesStyles.css";
import { shallow } from "zustand/shallow";
import { BaseNode } from "./baseNode";
import { useStore } from "../store";

export const TextNode = ({ id, data = {} }) => {
  const [currText, setCurrText] = useState(data?.text || "{{input}}");
  const spanRef = useRef(null);
  const inputRef = useRef(null);

  const selector = (state) => ({
    nodes: state.nodes,

    onConnect: state.onConnect,
  });

  const {
    nodes,

    onConnect,
  } = useStore(selector, shallow);

  function isValidInput(str) {
    const regex = /^input_\d+$/;

    return regex.test(str);
  }

  const handleTextChange = (e) => {
    let value = e.target.value;
    setCurrText(value);

    if (checkWrappedValue(value)) {
      let inputNodes = nodes.filter((node) => node.type === "customInput");

      if (inputNodes.length > 0) {
        if (isValidInput(value?.slice(2, -2))) {
          let inputId = value.split(`_`)[1][0];
          console.log(inputId)
          onConnect({
            source: `customInput-${inputId}`,
            sourceHandle: `customInput-${inputId}-value`,
            target: id,
            targetHandle: `${id}-input`,
          });
        }
      }
    }
  };

  useEffect(() => {
    if (spanRef.current && inputRef.current) {
      const newWidth = spanRef.current.offsetWidth + 20;
      inputRef.current.style.width = `${Math.max(newWidth, 60)}px`;
    }
  }, [currText]);

  function checkWrappedValue(inputValue) {
    const regex = /^\{\{.*\}\}$/;

    return regex.test(inputValue);
  }

  return (
    <BaseNode
      id={id}
      label="Text"
      handles={[
        { key: "output", type: "source", position: Position.Right },
        { key: "input", type: "target", position: Position.Left },
      ]}
    >
      <div>
        <label className="label">
          Text:
          <input
            ref={inputRef}
            type="text"
            value={currText}
            onChange={handleTextChange}
            className="input"
            style={{ width: "60px" }}
          />
        </label>
        <span
          ref={spanRef}
          className="input-width-calculator"
          style={{
            position: "absolute",
            visibility: "hidden",
            whiteSpace: "pre",
            fontSize: "14px",
            fontFamily: "inherit",
          }}
        >
          {currText || " "}
        </span>
      </div>
    </BaseNode>
  );
};
