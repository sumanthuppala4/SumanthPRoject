// FirstNode.jsx

import { useState } from "react";

import { Position } from "reactflow";


import "./nodesStyles.css";
import { BaseNode } from "./baseNode";

export const FirstNode = ({ id }) => {
  const [title, setTitle] = useState("");

  const [category, setCategory] = useState("General");

  return (
    <BaseNode
      id={id}
      label="First Node"
      description="Enter title and category"
      handles={[{ key: "out", type: "source", position: Position.Right }]}
    >
      <label className="label">
        Title:
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="input"
        />
      </label>

      <label className="label">
        Category:
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="select"
        >
          <option>General</option>

          <option>News</option>

          <option>Updates</option>
        </select>
      </label>
    </BaseNode>
  );
};
