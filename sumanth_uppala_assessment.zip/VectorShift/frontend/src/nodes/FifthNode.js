// FifthNode.jsx
import { Position } from "reactflow";
import { BaseNode } from "./baseNode";

export const FifthNode = ({ id }) => (
  <BaseNode
    id={id}
    label="Fifth"
    description="This is the Fifth Node."
    handles={[
      { key: "input", type: "target", position: Position.Left },
      { key: "output", type: "source", position: Position.Right },
      { key: "extra", type: "source", position: Position.Bottom },
    ]}
  />
);
