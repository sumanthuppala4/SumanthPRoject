// OutputNode.jsx
import { useState } from "react";
import { Position } from "reactflow";
import { BaseNode } from "./baseNode";

export const OutputNode = ({ id, data }) => {
  const [currName, setCurrName] = useState(
    data?.outputName || id.replace("customOutput-", "output_")
  );
  const [outputType, setOutputType] = useState(data?.outputType || "Text");

  const handleNameChange = (e) => setCurrName(e.target.value);
  const handleTypeChange = (e) => setOutputType(e.target.value);

  return (
    <BaseNode
      id={id}
      label="Output"
      handles={[
        {
          key: "value",
          type: "target",
          position: Position.Left,
        },
      ]}
    >
      {/* Custom fields */}
      <div>
        <label className="label">
          Name:
          <input
            type="text"
            value={currName}
            onChange={handleNameChange}
            className="input"
          />
        </label>

        <label className="label">
          Type:
          <select
            value={outputType}
            onChange={handleTypeChange}
            className="select"
          >
            <option value="Text">Text</option>
            <option value="File">Image</option>
          </select>
        </label>
      </div>
    </BaseNode>
  );
};
