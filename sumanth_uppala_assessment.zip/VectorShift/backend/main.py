from fastapi import FastAPI, Form
import json
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Allow frontend (React) to access backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # frontend origin
    allow_credentials=True,
    allow_methods=["*"],  # allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # allow all headers
)

@app.get('/')
def read_root():
    return {'Ping': 'Pong'}



from fastapi import Request
from typing import Dict, List, Any

def check_is_dag(nodes: List[Dict[str, Any]], edges: List[Dict[str, Any]]) -> bool:
    # Build adjacency list
    adj = {node["id"]: [] for node in nodes}
    for edge in edges:
        source = edge["source"]
        target = edge["target"]
        if source in adj:
            adj[source].append(target)
    
    # Helper function for DFS cycle detection
    def has_cycle(node: str, visited: set, path: set) -> bool:
        print(f"Visiting node: {node}")
        visited.add(node)
        path.add(node)
        
        for neighbor in adj.get(node, []):
            if neighbor not in visited:
                if has_cycle(neighbor, visited, path):
                    return True
            elif neighbor in path:
                return True
        
        path.remove(node)
        return False
    
    # Check each node for cycles
    visited = set()
    path = set()
    
    for node in adj:
        if node not in visited:
            if has_cycle(node, visited, path):
                return False  # Contains cycle, not a DAG
    
    return True  # No cycles found, is a DAG

@app.post('/pipelines/parse')
async def parse_pipeline_post(request: Request):
    try:
        data = await request.json()
        nodes = data.get("nodes", [])
        edges = data.get("edges", [])
        
        num_nodes = len(nodes)
        num_edges = len(edges)
        is_dag = check_is_dag(nodes, edges)
        
        return {
            "num_nodes": num_nodes,
            "num_edges": num_edges,
            "is_dag": is_dag
        }
    except Exception as e:
        print(f"Error processing pipeline: {str(e)}")
        return {"error": str(e)}
